"""FortifySec Labs: safe read-only integration pilot for CTFd 3.8.9."""
from flask import Blueprint, abort, jsonify, render_template_string
from CTFd.utils.user import get_current_user

bp = Blueprint('fortifysec_labs', __name__, url_prefix='/labs')

PAGE = '''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FortifySec Labs</title><style>body{background:#090f1c;color:#eef3ff;font:16px system-ui;margin:0;padding:3rem}main{max-width:900px;margin:auto}h1{font-size:2.4rem}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1rem}.card{background:#151f31;border:1px solid #34455c;border-radius:14px;padding:1.5rem}.muted{color:#9eb0cb}.pill{display:inline-block;padding:.3rem .7rem;border-radius:20px;background:#29394f;color:#b7d3fa}a{color:#b7d3fa}</style></head><body><main><p class="muted">FORTIFYSEC ARENA / LABS</p><h1>Laboratórios individuais</h1><p>Bem-vindo, {{ username|e }}. Esta é a prévia segura da integração. Nenhuma máquina será criada nesta fase.</p><div class="grid"><section class="card"><h2>Web Auth</h2><p class="muted">Autenticação e controle de acesso</p><span class="pill">Em preparação</span></section><section class="card"><h2>API IDOR</h2><p class="muted">Autorização em objetos da API</p><span class="pill">Em preparação</span></section><section class="card"><h2>Log Forensics</h2><p class="muted">Investigação de registros</p><span class="pill">Em preparação</span></section></div><p><a href="/challenges">Voltar aos desafios</a></p></main></body></html>'''

@bp.route('/', methods=['GET'])
def index():
    user = get_current_user()
    if user is None:
        abort(401)
    return render_template_string(PAGE, username=user.name)

@bp.route('/api/status', methods=['GET'])
def status():
    user = get_current_user()
    if user is None:
        abort(401)
    return jsonify({'mode': 'demo', 'authenticated': True, 'labs': ['web-auth', 'api-idor', 'log-forensics']})

def load(app):
    app.register_blueprint(bp)
