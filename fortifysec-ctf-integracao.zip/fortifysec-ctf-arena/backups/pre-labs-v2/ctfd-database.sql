/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ctfd
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES
('48d8250d19bd');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `type` varchar(80) DEFAULT 'standard',
  PRIMARY KEY (`id`),
  KEY `awards_ibfk_1` (`team_id`),
  KEY `awards_ibfk_2` (`user_id`),
  CONSTRAINT `awards_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `awards_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
INSERT INTO `awards` VALUES
(1,1,1,'Hint 10','Hint for BLACK CROWN: Operation ECLIPSE','2026-11-04 18:26:31.786915',-200,'hints',NULL,NULL,'standard'),
(2,1,1,'Hint 11','Hint for BLACK CROWN: Operation ECLIPSE','2026-11-04 18:26:39.379327',-350,'hints',NULL,NULL,'standard');
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brackets`
--

DROP TABLE IF EXISTS `brackets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `brackets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brackets`
--

LOCK TABLES `brackets` WRITE;
/*!40000 ALTER TABLE `brackets` DISABLE KEYS */;
/*!40000 ALTER TABLE `brackets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_topics`
--

DROP TABLE IF EXISTS `challenge_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `topic_id` (`topic_id`),
  CONSTRAINT `challenge_topics_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `challenge_topics_ibfk_2` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_topics`
--

LOCK TABLES `challenge_topics` WRITE;
/*!40000 ALTER TABLE `challenge_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenge_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `max_attempts` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `state` varchar(80) NOT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `connection_info` text DEFAULT NULL,
  `next_id` int(11) DEFAULT NULL,
  `attribution` text DEFAULT NULL,
  `logic` varchar(80) NOT NULL,
  `initial` int(11) DEFAULT NULL,
  `minimum` int(11) DEFAULT NULL,
  `decay` int(11) DEFAULT NULL,
  `function` varchar(32) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `next_id` (`next_id`),
  CONSTRAINT `challenges_ibfk_1` FOREIGN KEY (`next_id`) REFERENCES `challenges` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
INSERT INTO `challenges` VALUES
(1,'A Primeira Flag','Bem-vindo à FortifySec CTF Arena!\r\n\r\nNossa equipe interceptou uma mensagem codificada em Base64. Sua missão é decodificá-la e recuperar a flag.\r\n\r\nRk9SVElGWVN7Q1RGX0lOSUNJQURPfQ==\r\n\r\nFormato esperado: FORTIFY{...}',0,100,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(2,'FS-001 — Tenant Escape','**Laboratório FortifySec Elite Labs**\r\n\r\n# FS-001 — tenant-escape\r\n\r\nCategoria: Web | 450 pontos\r\n\r\nExecute `python3 app.py`, visite http://127.0.0.1:8101 e investigue a API de incidentes. Acesso de teste: auditor/fortify2027. Encontre a evidência secreta de outro tenant.\r\n\r\n\r\nBaixe o arquivo anexo e resolva em VM/container isolado. ',0,450,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(3,'FS-002 — Stream Reuse','**Laboratório FortifySec Elite Labs**\n\n# FS-002 — stream-reuse\n\nCategoria: Crypto | 500 pontos\n\nUm dispositivo reutilizou o mesmo keystream em dois pacotes. Use `known.txt` e `known.hex` para recuperar o conteúdo de `secret.hex`. Escreva um script Python.\n\n\nBaixe o arquivo anexo e resolva em VM/container isolado. Não execute binários vulneráveis no host do CTFd.',0,500,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(4,'FS-003 — Incident Timeline','**Laboratório FortifySec Elite Labs**\n\n# FS-003 — incident-timeline\n\nCategoria: Forensics | 500 pontos\n\nCorrelacione `telemetry.sqlite` e `proxy.log`. Identifique o payload transferido pelo usuário `analyst` APÓS a elevação de privilégio e ANTES da revogação da sessão. Não há rede.\n\n\nBaixe o arquivo anexo e resolva em VM/container isolado. Não execute binários vulneráveis no host do CTFd.',0,500,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(5,'FS-004 — ELF Keycheck','**Laboratório FortifySec Elite Labs**\n\n# FS-004 — elf-keycheck\n\nCategoria: Reverse | 550 pontos\n\nAnalise o executável Linux x86-64 `keycheck` com Ghidra/GDB/objdump. Recupere a licença válida; o programa imprimirá a flag. Execute em VM ou container descartável.\n\n\nBaixe o arquivo anexo e resolva em VM/container isolado. Não execute binários vulneráveis no host do CTFd.',0,550,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(6,'FS-005 — Stack Gate','**Laboratório FortifySec Elite Labs**\n\n# FS-005 — stack-gate\n\nCategoria: Pwn | 600 pontos\n\nAnalise `stack-gate` no GDB e explore um buffer overflow para alterar o estado de autorização. ELF Linux x86-64 deliberadamente vulnerável; use VM isolada.\n\n\nBaixe o arquivo anexo e resolva em VM/container isolado. Não execute binários vulneráveis no host do CTFd.',0,600,'Pwn','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(7,'FS-006 — DNS Fragments','**Laboratório FortifySec Elite Labs**\n\n# FS-006 — dns-fragments\n\nCategoria: Networks | 450 pontos\n\nAnalise o log DNS e identifique as consultas que carregam dados em labels hexadecimais. Reordene os fragmentos pelo índice e decodifique o conteúdo.\n\n\nBaixe o arquivo anexo e resolva em VM/container isolado. Não execute binários vulneráveis no host do CTFd.',0,450,'Networks','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(8,'Tenant Boundary II','Execute `python3 server.py` e investigue o controle de acesso da API local. Seu objetivo e recuperar a informacao pertencente a outro tenant.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,500,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(9,'Keystream Collision','Dois fluxos foram cifrados com a mesma chave XOR. Voce conhece o texto claro do primeiro. Recupere a mensagem confidencial do segundo.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,550,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(10,'Audit Trail Recovery','Analise o banco SQLite de um sistema de auditoria. Identifique a evidencia de recuperacao registrada logo apos uma exclusao suspeita.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,500,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(11,'DNS Exfil Fragments','Examine o PCAP no Wireshark ou tshark. Um agente fragmentou um segredo em consultas DNS. Reconstrua os fragmentos pela ordem indicada.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,600,'Redes','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(12,'ELF Checkpoint','Analise um binario ELF Linux x86-64 e recupere o token de validacao. Ferramentas sugeridas: file, strings, objdump, Ghidra e GDB.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,650,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(13,'Operacao Aurora','Investigue um conjunto de documentos ficticios offline. Correlacione identificadores, ordem de montagem e fragmentos para reconstruir a flag.\n\nBaixe o arquivo anexo para realizar o laboratorio.',0,450,'OSINT','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(14,'FS-013 — XOR Beacon','Recupere o conteúdo original de uma transmissão interceptada. Documente a transformação usada.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,350,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(15,'FS-014 — Vigenere Field Report','Recupere o conteúdo original de uma transmissão interceptada. Documente a transformação usada.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,390,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(16,'FS-015 — RSA Byte Blocks','Recupere o conteúdo original de uma transmissão interceptada. Documente a transformação usada.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,430,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(17,'FS-016 — Endian Trap','Recupere o conteúdo original de uma transmissão interceptada. Documente a transformação usada.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,470,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(18,'FS-017 — Compressed Signal','Recupere o conteúdo original de uma transmissão interceptada. Documente a transformação usada.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,510,'Criptografia','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(19,'FS-018 — SQLite Incident','Analise as evidencias locais e reconstrua o indicador de comprometimento solicitado.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,400,'Forense Digital','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(20,'FS-019 — Gateway Fragments','Analise as evidencias locais e reconstrua o indicador de comprometimento solicitado.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,435,'Forense Digital','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(21,'FS-020 — PNG Trailer','Analise as evidencias locais e reconstrua o indicador de comprometimento solicitado.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,470,'Forense Digital','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(22,'FS-021 — Hidden Archive','Analise as evidencias locais e reconstrua o indicador de comprometimento solicitado.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,505,'Forense Digital','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(23,'FS-022 — Journal Rotation','Analise as evidencias locais e reconstrua o indicador de comprometimento solicitado.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,540,'Forense Digital','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(24,'FS-023 — UDP Beacon','Inspecione a captura de rede usando Wireshark, tshark ou Python; recupere a evidência transmitida.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,450,'Redes','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(25,'FS-024 — Out-of-Order Datagram','Inspecione a captura de rede usando Wireshark, tshark ou Python; recupere a evidência transmitida.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,490,'Redes','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(26,'FS-025 — Hex Payload','Inspecione a captura de rede usando Wireshark, tshark ou Python; recupere a evidência transmitida.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,530,'Redes','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(27,'FS-026 — Rotated Traffic','Inspecione a captura de rede usando Wireshark, tshark ou Python; recupere a evidência transmitida.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,570,'Redes','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(28,'FS-027 — XOR Keycheck','Analise um executavel ELF x86-64 compilado para recuperar uma string transformada sem codigo-fonte.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,550,'Engenharia Reversa','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(29,'FS-028 — Additive Validator','Analise um executavel ELF x86-64 compilado para recuperar uma string transformada sem codigo-fonte.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,600,'Engenharia Reversa','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(30,'FS-029 — Reverse Lookup','Analise um executavel ELF x86-64 compilado para recuperar uma string transformada sem codigo-fonte.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,650,'Engenharia Reversa','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(31,'FS-030 — Bit Rotation','Analise um executavel ELF x86-64 compilado para recuperar uma string transformada sem codigo-fonte.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,700,'Engenharia Reversa','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(32,'FS-031 — Operation Glasshouse','Analise o dossie ficticio offline, correlacione os documentos e reconstrua a evidência em ordem cronologica.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,450,'OSINT','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(33,'FS-033 — Client-Side Trust','Execute a aplicacao HTML localmente, investigue a logica de validacao no navegador e recupere o token.\n\nBaixe o anexo, analise em um ambiente local e envie a flag no formato FSCTF{...}.',0,400,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(34,'FS-033 — Key Schedule','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,500,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(35,'FS-034 — Offset Protocol','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,530,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(36,'FS-035 — Reverse Base85','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,560,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(37,'FS-036 — Compressed Whisper','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,590,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(38,'FS-037 — Nibble Swap','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,620,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(39,'FS-038 — Nonce Derived Key','Recover the flag from the supplied cryptographic telemetry. Use the accompanying protocol notes.',0,650,'Cryptography','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(40,'FS-039 — Incident Database','Analyze the provided incident evidence and recover the hidden flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(41,'FS-040 — Exfil Event Stream','Analyze the provided incident evidence and recover the hidden flag.',0,575,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(42,'FS-041 — Archive Artifact','Analyze the provided incident evidence and recover the hidden flag.',0,600,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(43,'FS-042 — PNG Metadata','Analyze the provided incident evidence and recover the hidden flag.',0,625,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(44,'FS-043 — Gateway Alert','Analyze the provided incident evidence and recover the hidden flag.',0,650,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(45,'FS-044 — Telemetry Correlation','Analyze the provided incident evidence and recover the hidden flag.',0,675,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(46,'FS-045 — UDP Fragment Case 01','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,600,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(47,'FS-046 — UDP Fragment Case 02','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,625,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(48,'FS-047 — UDP Fragment Case 03','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,650,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(49,'FS-048 — UDP Fragment Case 04','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,675,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(50,'FS-049 — UDP Fragment Case 05','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,700,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(51,'FS-050 — UDP Fragment Case 06','Reconstruct a UDP transmission from a real PCAP file. Fragments arrive in reverse order and are encoded.',0,725,'Networking','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(52,'FS-051 — ELF Checkpoint 01','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,700,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(53,'FS-052 — ELF Checkpoint 02','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,735,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(54,'FS-053 — ELF Checkpoint 03','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,770,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(55,'FS-054 — ELF Checkpoint 04','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,805,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(56,'FS-055 — ELF Checkpoint 05','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,840,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(57,'FS-056 — ELF Checkpoint 06','Reverse engineer an actual x86-64 ELF executable and recover its required passphrase. Static analysis recommended.',0,875,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(58,'FS-057 — Client Artifact 01','Perform offline JavaScript source analysis and reconstruct a hidden client-side token.',0,650,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(59,'FS-058 — Client Artifact 02','Perform offline JavaScript source analysis and reconstruct a hidden client-side token.',0,685,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(60,'FS-059 — Client Artifact 03','Perform offline JavaScript source analysis and reconstruct a hidden client-side token.',0,720,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(61,'FS-060 — Client Artifact 04','Perform offline JavaScript source analysis and reconstruct a hidden client-side token.',0,755,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(62,'FS-061 — Orion Case 01','Correlate fictional investigation records and decode the evidence for the target alias.',0,550,'OSINT','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(63,'FS-062 — Orion Case 02','Correlate fictional investigation records and decode the evidence for the target alias.',0,600,'OSINT','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(64,'FS-063 — Merkle Breach','Offline evidence reconstruction. Download the attached FS-063.zip and submit the recovered proof token.',0,900,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(65,'FS-064 — CTR Nonce Collision','Offline evidence reconstruction. Download the attached FS-064.zip and submit the recovered proof token.',0,900,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(66,'FS-065 — Shamir Recovery','Offline evidence reconstruction. Download the attached FS-065.zip and submit the recovered proof token.',0,900,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(67,'FS-066 — RSA Broadcast Incident','Offline evidence reconstruction. Download the attached FS-066.zip and submit the recovered proof token.',0,900,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(68,'FS-067 — Padding Oracle Trace','Offline evidence reconstruction. Download the attached FS-067.zip and submit the recovered proof token.',0,900,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(69,'FS-068 — KDF Parameter Hunt','Offline evidence reconstruction. Download the attached FS-068.zip and submit the recovered proof token.',0,1000,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(70,'FS-069 — SQLite WAL Reconstruction','Offline evidence reconstruction. Download the attached FS-069.zip and submit the recovered proof token.',0,1000,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(71,'FS-070 — Timeline Correlation','Offline evidence reconstruction. Download the attached FS-070.zip and submit the recovered proof token.',0,1000,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(72,'FS-071 — Nested Evidence','Offline evidence reconstruction. Download the attached FS-071.zip and submit the recovered proof token.',0,1000,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(73,'FS-072 — Log Chain Integrity','Offline evidence reconstruction. Download the attached FS-072.zip and submit the recovered proof token.',0,1000,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(74,'FS-073 — Image Chunk Carving','Offline evidence reconstruction. Download the attached FS-073.zip and submit the recovered proof token.',0,1100,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(75,'FS-074 — Registry-like Artifact','Offline evidence reconstruction. Download the attached FS-074.zip and submit the recovered proof token.',0,1100,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(76,'FS-075 — DNS Fragment Recovery','Offline evidence reconstruction. Download the attached FS-075.zip and submit the recovered proof token.',0,1100,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(77,'FS-076 — TCP Stream Reassembly','Offline evidence reconstruction. Download the attached FS-076.zip and submit the recovered proof token.',0,1100,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(78,'FS-077 — Covert Timing Channel','Offline evidence reconstruction. Download the attached FS-077.zip and submit the recovered proof token.',0,1100,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(79,'FS-078 — HTTP Header Exfil','Offline evidence reconstruction. Download the attached FS-078.zip and submit the recovered proof token.',0,1200,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(80,'FS-079 — Protocol State Puzzle','Offline evidence reconstruction. Download the attached FS-079.zip and submit the recovered proof token.',0,1200,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(81,'FS-080 — Packet Ordering Trap','Offline evidence reconstruction. Download the attached FS-080.zip and submit the recovered proof token.',0,1200,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(82,'FS-081 — Virtual Machine Bytecode','Offline evidence reconstruction. Download the attached FS-081.zip and submit the recovered proof token.',0,1200,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(83,'FS-082 — Obfuscated State Machine','Offline evidence reconstruction. Download the attached FS-082.zip and submit the recovered proof token.',0,1200,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(84,'FS-083 — Custom Executable Format','Offline evidence reconstruction. Download the attached FS-083.zip and submit the recovered proof token.',0,1300,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(85,'FS-084 — Control Flow Graph','Offline evidence reconstruction. Download the attached FS-084.zip and submit the recovered proof token.',0,1300,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(86,'FS-085 — Symbolic Constraint Hunt','Offline evidence reconstruction. Download the attached FS-085.zip and submit the recovered proof token.',0,1300,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(87,'FS-086 — Endian Permutation','Offline evidence reconstruction. Download the attached FS-086.zip and submit the recovered proof token.',0,1300,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(88,'FS-087 — JWT Trust Boundary','Offline evidence reconstruction. Download the attached FS-087.zip and submit the recovered proof token.',0,1300,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(89,'FS-088 — GraphQL Authorization','Offline evidence reconstruction. Download the attached FS-088.zip and submit the recovered proof token.',0,1400,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(90,'FS-089 — Race Condition Ledger','Offline evidence reconstruction. Download the attached FS-089.zip and submit the recovered proof token.',0,1400,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(91,'FS-090 — Template Sandbox Escape','Offline evidence reconstruction. Download the attached FS-090.zip and submit the recovered proof token.',0,1400,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(92,'FS-091 — IAM Policy Escalation','Offline evidence reconstruction. Download the attached FS-091.zip and submit the recovered proof token.',0,1400,'Cloud','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(93,'FS-092 — Kubernetes RBAC Audit','Offline evidence reconstruction. Download the attached FS-092.zip and submit the recovered proof token.',0,1400,'Cloud','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(94,'FS-093 — Telemetry Recovery 1','Forensics | Medium - Analise o anexo e encontre a flag.',0,350,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(95,'FS-094 — Cipher Relay 1','Crypto | Medium - Analise o anexo e encontre a flag.',0,350,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(96,'FS-095 — SQLite Incident 1','Forensics | Medium - Analise o anexo e encontre a flag.',0,350,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(97,'FS-096 — Packet Reconstruction 1','Network | Medium - Analise o anexo e encontre a flag.',0,350,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(98,'FS-097 — Firmware Carving 1','Forensics | Medium - Analise o anexo e encontre a flag.',0,350,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(99,'FS-098 — Source Audit 1','Web | Medium - Analise o anexo e encontre a flag.',0,350,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(100,'FS-099 — Log Timeline 1','Forensics | Medium - Analise o anexo e encontre a flag.',0,350,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(101,'FS-100 — Archive Forensics 1','Forensics | Medium - Analise o anexo e encontre a flag.',0,350,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(102,'FS-101 — Binary Endianness 1','Reverse | Medium - Analise o anexo e encontre a flag.',0,350,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(103,'FS-102 — Multi-Stage Encoding 1','Crypto | Medium - Analise o anexo e encontre a flag.',0,350,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(104,'FS-103 — Telemetry Recovery 2','Forensics | Hard - Analise o anexo e encontre a flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(105,'FS-104 — Cipher Relay 2','Crypto | Hard - Analise o anexo e encontre a flag.',0,550,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(106,'FS-105 — SQLite Incident 2','Forensics | Hard - Analise o anexo e encontre a flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(107,'FS-106 — Packet Reconstruction 2','Network | Hard - Analise o anexo e encontre a flag.',0,550,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(108,'FS-107 — Firmware Carving 2','Forensics | Hard - Analise o anexo e encontre a flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(109,'FS-108 — Source Audit 2','Web | Hard - Analise o anexo e encontre a flag.',0,550,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(110,'FS-109 — Log Timeline 2','Forensics | Hard - Analise o anexo e encontre a flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(111,'FS-110 — Archive Forensics 2','Forensics | Hard - Analise o anexo e encontre a flag.',0,550,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(112,'FS-111 — Binary Endianness 2','Reverse | Hard - Analise o anexo e encontre a flag.',0,550,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(113,'FS-112 — Multi-Stage Encoding 2','Crypto | Hard - Analise o anexo e encontre a flag.',0,550,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(114,'FS-113 — Telemetry Recovery 3','Forensics | Expert - Analise o anexo e encontre a flag.',0,750,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(115,'FS-114 — Cipher Relay 3','Crypto | Expert - Analise o anexo e encontre a flag.',0,750,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(116,'FS-115 — SQLite Incident 3','Forensics | Expert - Analise o anexo e encontre a flag.',0,750,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(117,'FS-116 — Packet Reconstruction 3','Network | Expert - Analise o anexo e encontre a flag.',0,750,'Network','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(118,'FS-117 — Firmware Carving 3','Forensics | Expert - Analise o anexo e encontre a flag.',0,750,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(119,'FS-118 — Source Audit 3','Web | Expert - Analise o anexo e encontre a flag.',0,750,'Web','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(120,'FS-119 — Log Timeline 3','Forensics | Expert - Analise o anexo e encontre a flag.',0,750,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(121,'FS-120 — Archive Forensics 3','Forensics | Expert - Analise o anexo e encontre a flag.',0,750,'Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(122,'FS-121 — Binary Endianness 3','Reverse | Expert - Analise o anexo e encontre a flag.',0,750,'Reverse','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(123,'FS-122 — Multi-Stage Encoding 3','Crypto | Expert - Analise o anexo e encontre a flag.',0,750,'Crypto','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(124,'OBSIDIAN-47: The Broken Trust Anchor','An industrial security gateway has lost its trust anchor. Only a stripped Linux x86-64 recovery console remains. Reverse its attestation algorithm and recover the authentic 47-byte token.\n\n**Attachment:** `obsidian47-player.zip`\n\n**Flag format:** `FORTIFY{...}`\n\n**Scope:** Offline binary analysis only. No attacks on the hosting platform are required or permitted.',0,1000,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(125,'NEBULA-9: The Last Signal','Uma estação de retransmissão abandonada recebeu um último pacote de autenticação antes de desaparecer da rede. O executável `nebula9` valida um sinal de acesso, mas a implementação original e a documentação foram perdidas. Sua missão é recuperar a string exata que faz o terminal responder `SIGNAL ACCEPTED`.\n\n**Formato da flag:** `FORTIFY{...}`\n\n**Arquitetura:** Linux x86-64 (ELF).\n\n**Execução:** `chmod +x nebula9 && ./nebula9 \'SINAL\'`\n\nNão é necessário acessar serviços externos. Analise o arquivo apenas em ambiente de laboratório.\n',0,1000,'Reverse Engineering','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(127,'ORION: The Vanishing Session','## ORION: The Vanishing Session\n\nA compromised build server left behind proxy logs, an authentication database, and a masked evidence blob. Reconstruct the authenticated session, correlate the artifact export and audit deletion, and recover the incident marker.\n\nDownload the attached evidence package. No remote target is required.\n\n**Flag format:** `FORTIFYSEC{...}`',0,1000,'Digital Forensics','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(129,'BLACK CROWN: Operation ECLIPSE','Reconstruct a five-stage simulated identity compromise from a synthetic corporate evidence bundle. Identify the principal, correlate authentication and access traces, recover message-bus fragments and derive the incident seal. Download the attached evidence archive. All activity is offline; no external targets.',0,2500,'Red Team Operations','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0),
(130,'PROJECT CERBERUS: The Supply Chain Breach','Investigate a fictional compromised release pipeline. Download the archive, build the isolated Docker lab, correlate provenance and registry telemetry, and recover the release seal. All activity is offline.',0,1500,'Container Security','standard','visible',NULL,NULL,NULL,NULL,'any',NULL,NULL,NULL,'static',0);
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `page_id` (`page_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_4` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES
(1,'ctf_version','3.8.9'),
(2,'dynamic_challenges_alembic_version','93284ed9c099'),
(3,'ctf_name','FortifySec CTF Arena 2027'),
(4,'ctf_description','A FortifySec CTF Arena 2027 é uma competição oficial de segurança cibernética no formato Capture The Flag (CTF). Os participantes enfrentarão desafios de Web Security, OSINT, Criptografia, Forense Digital, Redes, Engenharia Reversa e Exploração de Vulnerabilidades.\r\n\r\nA competição oferece R$ 5.000 em premiações: R$ 3.000 para o primeiro lugar, R$ 1.500 para o segundo e R$ 500 para o terceiro.\r\n\r\nParticipe individualmente ou em equipes de até quatro integrantes e coloque suas habilidades à prova.'),
(5,'user_mode','teams'),
(6,'ctf_theme','fortifysec'),
(7,'start',''),
(8,'end',''),
(9,'freeze',NULL),
(10,'challenge_visibility','public'),
(11,'registration_visibility','public'),
(12,'score_visibility','public'),
(13,'account_visibility','public'),
(14,'verify_emails','false'),
(15,'social_shares','true'),
(16,'team_size','4'),
(17,'mail_server',NULL),
(18,'mail_port',NULL),
(19,'mail_tls',NULL),
(20,'mail_ssl',NULL),
(21,'mail_username',NULL),
(22,'mail_password',NULL),
(23,'mail_useauth',NULL),
(24,'setup','1'),
(25,'version_latest',NULL),
(26,'next_update_check','1793924188'),
(27,'theme_header',''),
(28,'theme_footer',''),
(29,'theme_settings',''),
(30,'default_locale','pt_BR');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_challenge`
--

DROP TABLE IF EXISTS `dynamic_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dynamic_challenge` (
  `id` int(11) NOT NULL,
  `dynamic_initial` int(11) DEFAULT NULL,
  `dynamic_minimum` int(11) DEFAULT NULL,
  `dynamic_decay` int(11) DEFAULT NULL,
  `dynamic_function` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dynamic_challenge_ibfk_1` FOREIGN KEY (`id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_challenge`
--

LOCK TABLES `dynamic_challenge` WRITE;
/*!40000 ALTER TABLE `dynamic_challenge` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamic_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_entries`
--

DROP TABLE IF EXISTS `field_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`value`)),
  `field_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `field_entries_ibfk_1` FOREIGN KEY (`field_id`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `field_entries_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `field_entries_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_entries`
--

LOCK TABLES `field_entries` WRITE;
/*!40000 ALTER TABLE `field_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `field_type` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `public` tinyint(1) DEFAULT NULL,
  `editable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `sha1sum` varchar(40) DEFAULT NULL,
  `solution_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `files_ibfk_1` (`challenge_id`),
  KEY `solution_id` (`solution_id`),
  CONSTRAINT `files_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `files_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  CONSTRAINT `files_ibfk_3` FOREIGN KEY (`solution_id`) REFERENCES `solutions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES
(1,'challenge','49df1d490421aab7122309308a05ebc2/FS-001-tenant-escape.zip',2,NULL,'bc9fbee0832461ad41c6c5a4e4b57b0e75a15127',NULL),
(2,'challenge','80628fb2f51f4f46437314ceb26e5825/FS-002-stream-reuse.zip',3,NULL,'e795423b22dfd19766a0ff171b7d9e3bab65f3b2',NULL),
(3,'challenge','90c567f73c23e952907dbc36f5c59ace/FS-003-incident-timeline.zip',4,NULL,'b82772e3e5dd128382864e53424f29d20606dd00',NULL),
(4,'challenge','18a8adf7eac312deb00f12ac900b61bf/FS-004-elf-keycheck.zip',5,NULL,'644b548c1b403930d7527dd53590b9d1cce39008',NULL),
(5,'challenge','ae947f3810a74b07e8d0c61ffc40ec57/FS-005-stack-gate.zip',6,NULL,'4e0d63ce791bc8c2efe4f26bbe137f2b6da70ba8',NULL),
(6,'challenge','2f8d9b465e9163c1c9dd8324e5bd77bc/FS-006-dns-fragments.zip',7,NULL,'9304659a7f152b444b7cfb8e284098949ff77c4d',NULL),
(7,'challenge','9a0727b733158b0dd295f0610853f876/FS-007.zip',8,NULL,'ac83995165bac29e9fda618988b2f8a55545afe5',NULL),
(8,'challenge','d7f8cd4ee83016743f876e10540ba70a/FS-008.zip',9,NULL,'62587effc08aefce99a330eb7cef6a2e2ed9fc93',NULL),
(9,'challenge','ef9beec47cbd414995b9b45933fad3ef/FS-009.zip',10,NULL,'01e65d80c5327f225c60e1d0a8e6ac3aac792cf8',NULL),
(10,'challenge','08369819820b03255d3d3ab13023cd9f/FS-010.zip',11,NULL,'b9bad30a61e4909d07b9e6b59efb273ec36da43a',NULL),
(11,'challenge','55e6e0801e30033a03528400805615e5/FS-011.zip',12,NULL,'83edaaf60fcbeadc0f1bb2af909a6e0a373f231c',NULL),
(12,'challenge','6d4d737d89c0e0013ba2dc2e64f02629/FS-012.zip',13,NULL,'d2aa77dc53df8802d9944125b62f321421251f7f',NULL),
(13,'challenge','b6f23c94d0852807f89ff972dbd67032/FS-013.zip',14,NULL,'9ff1f87c0c854d0e54d97b5456161e0075c5b848',NULL),
(14,'challenge','9e4894aadd613f0f3f8aeb92b615d5df/FS-014.zip',15,NULL,'b9f658b790ef45012c02d4e7d0d9f3e876cf40f4',NULL),
(15,'challenge','5943e54cf76fc950988d37f38304daf2/FS-015.zip',16,NULL,'76ad315333c06c65d3e87b5ec697d29458b686c3',NULL),
(16,'challenge','16e5eb9b0de72bbb0812e50e3d74df0d/FS-016.zip',17,NULL,'a2713752d309250e958438acd805ed47ef53f374',NULL),
(17,'challenge','d7880a4648b33e343a6fd14a96dcbe21/FS-017.zip',18,NULL,'49deaf10374cb64051e3bb87f5aa34e45a65315e',NULL),
(18,'challenge','bd892625ff69b2fe1eb34f0a20ba5ec9/FS-018.zip',19,NULL,'eeac6cc9b297053bbd1a1e9a3b5fe68677df40ca',NULL),
(19,'challenge','7e92098bbccd99533ba22ecc915224a9/FS-019.zip',20,NULL,'13fe46b51c40bd840bdc23393645839becce4379',NULL),
(20,'challenge','79c19e40a24b1297286330a7c419ad07/FS-020.zip',21,NULL,'79d7901322c632c2be36470a6c2bea2ee9738ac1',NULL),
(21,'challenge','70f4b64844684c15f20b19e0b6f6cde1/FS-021.zip',22,NULL,'875ebf3b4224e4771f56dd058f7eb48d749a36ff',NULL),
(22,'challenge','186d6dcd59290f793133a2360277ab0a/FS-022.zip',23,NULL,'0f8915b4eaac11ede950009037f518cb22c32c3a',NULL),
(23,'challenge','f598f106f8693d13dd5f27e820ea25bb/FS-023.zip',24,NULL,'b5af486d6b70968542f3ae9d6aafb495d1a8d162',NULL),
(24,'challenge','5a039b362ce6ffac1f36fa7ad571d8b9/FS-024.zip',25,NULL,'4887f989a6d3d588d9fdaa5f0d3f898ea5be4082',NULL),
(25,'challenge','8357adeec801b61a6f3878f85424de65/FS-025.zip',26,NULL,'8877972775f386fa455fa9bb9419f6592663968f',NULL),
(26,'challenge','471202793b0d2a350e4e338f8532d839/FS-026.zip',27,NULL,'eec01b70862bf4b3a1b7d5e4a2f4caf86e51b841',NULL),
(27,'challenge','40604dacc08fe766167c0831713db607/FS-027.zip',28,NULL,'231651076ccb8e50e2d8b3b3a41772d09a98d587',NULL),
(28,'challenge','d721424f5e30fdbfecddb5eb0176f0e6/FS-028.zip',29,NULL,'a53365b742b313bf9de0b28eec5dbdad5d55879d',NULL),
(29,'challenge','67679a7258da9d09bf48cdacdd3be61c/FS-029.zip',30,NULL,'6a10d7f749df490c57a2a877fa4d04fdd083faa1',NULL),
(30,'challenge','5a148f67dd6e171227c270ae8316d7f3/FS-030.zip',31,NULL,'c07fe5558d2eae565844a2da50f5d3d4c3c7c45a',NULL),
(31,'challenge','9dc73af7a0d95e800f8d23d4ff2e70ab/FS-031.zip',32,NULL,'77354a81c1c975b4bcf3d93d63056ddbd34cb9bc',NULL),
(32,'challenge','51bad4261a96f919ebf252d4b5585cd7/FS-033.zip',33,NULL,'7179b63b575e0ae520f9f88adf893632c9d00740',NULL),
(33,'standard','3fc23f3a080fbf54c713b7d315cf7ff7/FS-033.zip',NULL,NULL,'d4c5d1b730731bb9851fae503b364a8eb2e9bff2',NULL),
(34,'standard','75ced3c9a39bf65361a16afc5f8d913c/FS-034.zip',NULL,NULL,'91243891d52d36429cf14c7f9ea8989996d08183',NULL),
(35,'standard','1c62d0bdabd715f9ee714e74c0371c47/FS-035.zip',NULL,NULL,'e81a1078f0595607aba230b8f859d29d9f2b1d19',NULL),
(36,'standard','b9f3d2032bd5d3aa9e8092711fdb348c/FS-036.zip',NULL,NULL,'e90ca06cbb6c07c1bdb7e3dd721a6236a1554f47',NULL),
(37,'standard','d8e8715ffb01cc1e748a36c0f41a16ba/FS-037.zip',NULL,NULL,'048c21c7ec70aeb947d0d12e26cb430d3a982ce0',NULL),
(38,'standard','ecf0cf10748ee337009eaadb98c675f5/FS-038.zip',NULL,NULL,'c6952c3c2f494be985d18744e685a7246e9d708e',NULL),
(39,'standard','bdc6f577b12fe0d7fae332593b79257e/FS-039.zip',NULL,NULL,'ee908109cb9ba39c53f619f5a0c1aa2c5046904e',NULL),
(40,'standard','070750893fc7886e314f756a373aaaf3/FS-040.zip',NULL,NULL,'e6876ba4548c3c9636b7cb069fbce8182c801473',NULL),
(41,'standard','5f33c50dea18ef1a5efb511fed253ab1/FS-041.zip',NULL,NULL,'b13627a918c54eb4938f3867201435feb0bfdefb',NULL),
(42,'standard','ff9780d9f60e12ce29cb9810ae78c738/FS-042.zip',NULL,NULL,'8c7cc1641fc2967b847cef11d5aede0fe7eb042f',NULL),
(43,'standard','abdf1429b3baa8054bdf2d476de0e055/FS-043.zip',NULL,NULL,'9ad3b508fdee8952473898ea7a22d6586efb9aab',NULL),
(44,'standard','ec109f4b373eb6d33ad0915b1b409098/FS-044.zip',NULL,NULL,'62897e000415c33a6b0157a48e5cee2642cc0c9f',NULL),
(45,'standard','2b5ea93aa2f9971f6c9ca54d106cb8ba/FS-045.zip',NULL,NULL,'2cdb56265b6d7cdf3cd21d3428aaff07ee6f45ad',NULL),
(46,'standard','4cc47c479764544374c66c4f3786c1cf/FS-046.zip',NULL,NULL,'e156f466750dc69c1856e017f7965be0291060e1',NULL),
(47,'standard','cfa0ae7b488a416a0a31ea7c30ee7446/FS-047.zip',NULL,NULL,'40a9b162c74fbaeb2f7f6220b578b82dd29248b0',NULL),
(48,'standard','0fe04a31bf0efec8f18f6fae1b1155b6/FS-048.zip',NULL,NULL,'966b1a12b6445a669feeb2d0842378062bcaa166',NULL),
(49,'standard','cf68467e7013b2dd606eb560d559d91b/FS-049.zip',NULL,NULL,'9ce83e9a09e3012d7b73b916964e400ca9254131',NULL),
(50,'standard','ebb4e84cd587a8752239435733a20f9b/FS-050.zip',NULL,NULL,'7d6c5551e81a0e755d5300a3d7509114eb1bf1d4',NULL),
(51,'standard','eb5f037ffdbcf67f8881fbbe3e26ac0c/FS-051.zip',NULL,NULL,'7a80282d0378ef5a809ce57ae9d71d25e884afdc',NULL),
(52,'standard','a3d755a464b3331e5caa261e54e0855b/FS-052.zip',NULL,NULL,'f25abda91f6e0fce8b7bc3701edf09a741c835af',NULL),
(53,'standard','fbbd62aa867f0826a0361e8abf75e369/FS-053.zip',NULL,NULL,'f2e008032675371c3a9dfdcdf74f18ad022ab101',NULL),
(54,'standard','78689b2fa9ef3d9096e5f7dca883ac26/FS-054.zip',NULL,NULL,'9db8e49f8d477c4ee9cf165e77c4898bc1af36af',NULL),
(55,'standard','ceaece01647903b244dbd62321134601/FS-055.zip',NULL,NULL,'0128122c2988c438ba4e672c9b977aa424d0d5de',NULL),
(56,'standard','cd72f6231d3aeb8e85f2fef2739d13c5/FS-056.zip',NULL,NULL,'ae6d3f6055ad03a78d10b190905523ed73fcb856',NULL),
(57,'standard','517777a1da2cf6a3140839229d396267/FS-057.zip',NULL,NULL,'0efa586d771ef63e7a674f6b047d604a6757c200',NULL),
(58,'standard','7d2f50ced6581ca96aaa4b8e857a3d9f/FS-058.zip',NULL,NULL,'dd01550fa4e94637861582b72853ae8b80c38681',NULL),
(59,'standard','8ad72139e319396b7828f8c9d148f826/FS-059.zip',NULL,NULL,'926f202f6f1f0178fbb5f4a9abcd40d04f180bac',NULL),
(60,'standard','bd221bf4de14504aa04427238dba475d/FS-060.zip',NULL,NULL,'c03a87fb7bd2a1760813be4042785d624aad73b5',NULL),
(61,'standard','592e020bc301f1580e255652a55b8330/FS-061.zip',NULL,NULL,'cd4b480199b7c2a80a41f2716631eda1af3fb20d',NULL),
(62,'standard','b374661c3b98ce403ec5c66803c9c4e9/FS-062.zip',NULL,NULL,'25262aabc36b8d425849dbf8d3f9ef7e676fbab8',NULL),
(63,'challenge','75c4bc96dfea8d72b9b37f4431dad6f8/FS-063.zip',64,NULL,'c771a60828b8bca91b1114ed3b47b6cbe6d94bd6',NULL),
(64,'challenge','89838e5bfd533d4d606716270b9c8361/FS-064.zip',65,NULL,'4c9e006982a301fef731d09154a2cef56436e04d',NULL),
(65,'challenge','fc4d38ad9532d3b919f55ba8c782815d/FS-065.zip',66,NULL,'08f69deecfc3726520545a23a42dec3ae58d7110',NULL),
(66,'challenge','1013ccd4b589a5fc671028e917e1600a/FS-066.zip',67,NULL,'346a27c805780c2e3b6a16aa895cd20f4d467b8d',NULL),
(67,'challenge','561180fe5d2469f0e15747cea1317d2b/FS-067.zip',68,NULL,'8e04a6fb62b8e577badcbcb328cdf6fb49f65e0a',NULL),
(68,'challenge','166c77f2e70124f47f91bd2ba5f96411/FS-068.zip',69,NULL,'8af49a1a7747c73d58867618233eb0b13e608c1d',NULL),
(69,'challenge','956ff4378418f0780863caa7860839f2/FS-069.zip',70,NULL,'65b74eebd57b4707011792a7e902290e6a3abcda',NULL),
(70,'challenge','132d7ad930e3138fdcc90dcd5be10d3d/FS-070.zip',71,NULL,'3ee018de95d5fae1a01c47daa8f0a0fff295c20d',NULL),
(71,'challenge','46eb4828da11a6e4251b95a958b6dd48/FS-071.zip',72,NULL,'4fb75a1c153685fb3eddc742e177fff57be3f45e',NULL),
(72,'challenge','84ce789b0a70f75d88af00bc180de97a/FS-072.zip',73,NULL,'0544b15757d748305fb7493ebe356ebe8112e95a',NULL),
(73,'challenge','b0a7947d2eac41bd679795aa60a6fc7f/FS-073.zip',74,NULL,'891401f788f58e683ad9e68c333946d53c888410',NULL),
(74,'challenge','5c4bccc52891c7f772dd34842894c778/FS-074.zip',75,NULL,'65169c544de0f3d7385101b62b23b5879476dd03',NULL),
(75,'challenge','e9e61f3fda6f86fc1ad0ba2b72ded329/FS-075.zip',76,NULL,'33466783ef697fd1d22245d4dc77e4177c437090',NULL),
(76,'challenge','44086b49399bc43f1b45f7061d97b6e5/FS-076.zip',77,NULL,'4d014cce18957eb23355b0142a4f410966e23e84',NULL),
(77,'challenge','c92a6634485ddcbd7b82f1dad7720141/FS-077.zip',78,NULL,'a9037b3702d3dde4c85dea03b975da274473c704',NULL),
(78,'challenge','9a1d93338d5a4c3afa426ec00530662a/FS-078.zip',79,NULL,'dbec854064466d8f9c1a5abce7e1ed7fc03cefc4',NULL),
(79,'challenge','28822d52b2e315c6bb168815dabd16cc/FS-079.zip',80,NULL,'d281ab549f129d23c751d5b57a4ce30d047f5d56',NULL),
(80,'challenge','2cd66989d49886d546619afc79a7e994/FS-080.zip',81,NULL,'1e9ca7827c3dd5288130aa5ba3eda3b60610bacd',NULL),
(81,'challenge','410e25839e0ec437cca15fab2ffd3c42/FS-081.zip',82,NULL,'f0024c762ded23880e538bffff809d78fa66fdc1',NULL),
(82,'challenge','ed44372a3b73040262b3bfa761607c1a/FS-082.zip',83,NULL,'ad534367d6196aa48fd2abd86f2f175411b75ead',NULL),
(83,'challenge','f03a0162bf320e2a28ee777aee0b0021/FS-083.zip',84,NULL,'82e063898071334308d0459cfc7ad71724afa2b9',NULL),
(84,'challenge','b47e90a98e1cf5c45011decc3374c57d/FS-084.zip',85,NULL,'54116a3f3e4f14e3e9790e734808d406cc3c56e3',NULL),
(85,'challenge','ba8140a1b8a586e75a0c9c22a613389e/FS-085.zip',86,NULL,'12d78b10546af45a11a9ff54b2993725bf1789a8',NULL),
(86,'challenge','ffc743ab1123d700d9076e851dbe7456/FS-086.zip',87,NULL,'a6335ca2e5f88cfb538538e452448f75e6aef79d',NULL),
(87,'challenge','f9434aeca595745b00d700b2298ccb44/FS-087.zip',88,NULL,'1dec222a9fb1e5342656892e18e9f6d9ebf89443',NULL),
(88,'challenge','2fdfa1ce0ee909045d0e7fd8527828be/FS-088.zip',89,NULL,'386f97da8ef0d3e31ad728fb3a26f1bb1754e674',NULL),
(89,'challenge','c9acb4f628fbbc76c0895ca9caf79344/FS-089.zip',90,NULL,'01ecb03a713adfbb4c448cc91eb8c4e50b966680',NULL),
(90,'challenge','79f38c3f55e6cc3bd31f6173c9587925/FS-090.zip',91,NULL,'948ad5b826a6d7e9da99e7a216004f2bbbe3b0d6',NULL),
(91,'challenge','658a59b6accf61c2bd84df6350bddb71/FS-091.zip',92,NULL,'08ef7513a47e7b91087fef0e5bf71ec27df7142f',NULL),
(92,'challenge','18b138b63bf1469c30ec52cd5a5b1fb7/FS-092.zip',93,NULL,'28a08f96b83544ab2c10adb49b09686d4e18350b',NULL),
(93,'challenge','412bca20c372d3256041a97677e420f4/FS-093.zip',94,NULL,'c8eafcb32e21b73846aff459784df55b63d756af',NULL),
(94,'challenge','8f360b70389fdabfdc64b5bcf2b25441/FS-094.zip',95,NULL,'171ef317a5a306e69a339f30a8687e8df3284e8b',NULL),
(95,'challenge','b0732f9bd41fa9b7862ae63b396b68ac/FS-095.zip',96,NULL,'fb09744256047d28100d372712a3eb7648624d92',NULL),
(96,'challenge','0a4e61dea721de161c488c52fd65776f/FS-096.zip',97,NULL,'d0086d5208c56b67c9f9ea2c62eddb6be3c9e9d0',NULL),
(97,'challenge','b5eadbdb21e0f4e8590b887a15810328/FS-097.zip',98,NULL,'8022ea8ccdac45f4c7c63a6ef185eee617b65d8a',NULL),
(98,'challenge','dd3bf3b0a033804c1582fd837432573d/FS-098.zip',99,NULL,'8d4cfb84d3b7e42482b188cdc009a335567e8355',NULL),
(99,'challenge','365ac706b362fac2a6f36234261f03a6/FS-099.zip',100,NULL,'e90923f9bef96e469162c835b61b25aa0906ada3',NULL),
(100,'challenge','b4c77f179a2542da492d8129edf34a76/FS-100.zip',101,NULL,'6986bbfbcf390b5b1475b6afea75a4130f23a0b4',NULL),
(101,'challenge','21ed95593d6ed8bbf84f2c2088536621/FS-101.zip',102,NULL,'af04b698a8b2317fb7c203be3c74aab2464e6d6b',NULL),
(102,'challenge','1bdb693937e5ad37c8ddf08066e24b67/FS-102.zip',103,NULL,'0135998b40fe65e0804012c8b79ffb024720fca1',NULL),
(103,'challenge','cc2e65ca4476b717bf6ac878024d4651/FS-103.zip',104,NULL,'8c706e265c5298732255517c13005041a33156e9',NULL),
(104,'challenge','91809872976518cd736593ae52f9188a/FS-104.zip',105,NULL,'1b7b02cdf958a60e7afd1034cd6aabcbbe088070',NULL),
(105,'challenge','5a6b44a1514f87783ae4427db7712ab3/FS-105.zip',106,NULL,'52c5b9072b67c0be7a5e8fae55c23ab0cea644a4',NULL),
(106,'challenge','5a6d8048edf7ac37a39dc20730ad370b/FS-106.zip',107,NULL,'b3428fd654e7057bf009764988ebd21c1fbd2ad8',NULL),
(107,'challenge','74d413867b3bb7b9e0a2b2c454ac5d23/FS-107.zip',108,NULL,'cba09cb78c2a22f3481fb6629452424eefb5ed89',NULL),
(108,'challenge','f61963f1206b2a1d33537301b5550c16/FS-108.zip',109,NULL,'94ef31c44f163bcf9e05163203a6b76ac80be29e',NULL),
(109,'challenge','f68f611947357dea515e42666c7c0c15/FS-109.zip',110,NULL,'98c4558745cd8b5fceea639585ab8a8dc9d00163',NULL),
(110,'challenge','e57f1e0dabfd5cc5e3e2a82c183f5bb5/FS-110.zip',111,NULL,'6175776e0b006723707488ff20218b6b8f43bb6f',NULL),
(111,'challenge','4474fd93a710d9ca9f34fac2070d96ca/FS-111.zip',112,NULL,'987bff7c156a904bc06357339b643164b599170f',NULL),
(112,'challenge','bc7799f4244adeafbfb00143b7eec325/FS-112.zip',113,NULL,'9f07d1e1f2d1b792753510b1071b6b0d03d8bb8d',NULL),
(113,'challenge','ae25f00c9f9cf0d8c7ca8db2b785bfb1/FS-113.zip',114,NULL,'878abeb1b31efc210e9897c5c603e581c4eab6a8',NULL),
(114,'challenge','deab9d675dcdfdf1a02ec4283c375a9a/FS-114.zip',115,NULL,'03880cdf4773897aea237909d27d2dd7d777016a',NULL),
(115,'challenge','c065bcb5ed2b19306dda76aa774fa1f0/FS-115.zip',116,NULL,'0cec2dc84538c7ec3ce9124a5734f97ec506909f',NULL),
(116,'challenge','824b12c3d107adf041adeb53abaa822a/FS-116.zip',117,NULL,'95abbf8c8b224d677531e3b245627b52e7db9fdc',NULL),
(117,'challenge','266a7e80eee33c9eb58b1b6235804404/FS-117.zip',118,NULL,'784941719de3a2ac30e1f0a47cda52851b942cd1',NULL),
(118,'challenge','9cac550fe27a579c225d7fd3e66a79dc/FS-118.zip',119,NULL,'88bf6af212d94df87faa701368086dc6923d661c',NULL),
(119,'challenge','a75b2e352801832caaf8b6bcb06bc584/FS-119.zip',120,NULL,'3d673675d8cda379e846feb6e2610defe5afdd36',NULL),
(120,'challenge','35fb6f4d46dd2e4c9387bfd988361ef7/FS-120.zip',121,NULL,'5c590292894cf4948735f822ab3002346884f878',NULL),
(121,'challenge','3ebdf6550cdf9542a464b10caba677df/FS-121.zip',122,NULL,'a644b28ccffa009f281af8c41dac77072bb1eb4c',NULL),
(122,'challenge','edec71515681ae8c2ab809158977ee79/FS-122.zip',123,NULL,'54c20fd346d4901244e6155fa384b275bc44c9b5',NULL),
(123,'challenge','ab683bfe2af1d4d6c5a569826a21f2d2/obsidian47-player.zip',124,NULL,'03272834493b73a1e2b2d6fd85561eed7a487539',NULL),
(124,'standard','b37bcd9535b74cf20b9cd38fd45c8ed4/nebula9-player.zip',NULL,NULL,'bce5da8ae4af3648898d09f48009c54956bf7df1',NULL),
(125,'standard','5d9d06a0c6fd4577c9a38c8c1d503608/nebula9-player.zip',NULL,NULL,'bce5da8ae4af3648898d09f48009c54956bf7df1',NULL),
(126,'standard','f755b4f2effc77e382f35e434e7692ac/orion-player.zip',NULL,NULL,'ae3c461162bd7faaca7e1be1f57c0da8391d044b',NULL),
(127,'standard','b27b9362e6d8273504ed7e28760821d1/blackcrown-player.zip',NULL,NULL,'c4a5cf36eaf1a7aa1fba274ca91d542eb0fe984a',NULL),
(128,'standard','b08e66202d381992cfb4e7c468304440/blackcrown-player.zip',NULL,NULL,'c4a5cf36eaf1a7aa1fba274ca91d542eb0fe984a',NULL),
(129,'standard','318fd99643a72397c850938730f3bd8c/blackcrown-player.zip',NULL,NULL,'c4a5cf36eaf1a7aa1fba274ca91d542eb0fe984a',NULL),
(130,'challenge','42ec814fec61ba369966428af24d6be1/blackcrown-player.zip',129,NULL,'c4a5cf36eaf1a7aa1fba274ca91d542eb0fe984a',NULL),
(131,'challenge','dd44fa7d9727638e5912a73bbf5349e1/cerberus-player.zip',130,NULL,'a9ba2e63b9b7c020e4c9bdfa303670f804695aeb',NULL);
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flags_ibfk_1` (`challenge_id`),
  CONSTRAINT `flags_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
INSERT INTO `flags` VALUES
(1,1,'static','FORTIFYS{CTF_INICIADO}',''),
(2,2,'static','FSCTF{001_CROSS_TENANT_IDOR}',NULL),
(3,3,'static','FSCTF{002_NONCE_REUSE_RECOVERY}',NULL),
(4,4,'static','FSCTF{003_TIMELINE_CORRELATION}',NULL),
(5,5,'static','FSCTF{004_REVERSE_BYTE_TRANSFORM}',NULL),
(6,6,'static','FSCTF{005_STACK_GATE_OVERWRITE}',NULL),
(7,7,'static','FSCTF{006_DNS_EXFIL_FRAGMENTED}',NULL),
(8,8,'static','FSCTF{TENANT_BOUNDARY_14C8FE49DF}',''),
(9,9,'static','FSCTF{STREAM_COLLISION_B97E892105}',''),
(10,10,'static','FSCTF{AUDIT_TRAIL_7A74DC1A49}',''),
(11,11,'static','FSCTF{DNS_EXFIL_BEB0AE6DBA}',''),
(12,12,'static','FSCTF{ELF_CHECKPOINT_B165226730}',''),
(13,13,'static','FSCTF{CORRELATION_CASE_B39A17E410}',''),
(14,14,'static','FSCTF{ELITE_013_24E67F0BAA93}',''),
(15,15,'static','FSCTF{ELITE_014_7503E739B034}',''),
(16,16,'static','FSCTF{ELITE_015_BCAE52067225}',''),
(17,17,'static','FSCTF{ELITE_016_BE133F747D48}',''),
(18,18,'static','FSCTF{ELITE_017_8A49FA79FF6C}',''),
(19,19,'static','FSCTF{ELITE_018_0D05ED7BD8D6}',''),
(20,20,'static','FSCTF{ELITE_019_D56AB5EA19F0}',''),
(21,21,'static','FSCTF{ELITE_020_30F30D5EF603}',''),
(22,22,'static','FSCTF{ELITE_021_EC640367CC4E}',''),
(23,23,'static','FSCTF{ELITE_022_B59EF7A70EB9}',''),
(24,24,'static','FSCTF{ELITE_023_7428718CEE18}',''),
(25,25,'static','FSCTF{ELITE_024_C4919113FFC4}',''),
(26,26,'static','FSCTF{ELITE_025_2441EB50878A}',''),
(27,27,'static','FSCTF{ELITE_026_83FB57CFAEEE}',''),
(28,28,'static','FSCTF{ELITE_027_57D279869C87}',''),
(29,29,'static','FSCTF{ELITE_028_CD01375AB46E}',''),
(30,30,'static','FSCTF{ELITE_029_2FDCC53CE885}',''),
(31,31,'static','FSCTF{ELITE_030_86507C6DC3BD}',''),
(32,32,'static','FSCTF{ELITE_031_DA4E93262EA2}',''),
(33,33,'static','FSCTF{ELITE_033_255CBB576BE5}',''),
(34,34,'static','FORTIFY{FS033_21a77815a755dd5133}',''),
(35,35,'static','FORTIFY{FS034_b0d399b86b8ba37d9b}',''),
(36,36,'static','FORTIFY{FS035_10b37e88cf242812c5}',''),
(37,37,'static','FORTIFY{FS036_951bcd7f5844291535}',''),
(38,38,'static','FORTIFY{FS037_bc6ddef5677340d1a7}',''),
(39,39,'static','FORTIFY{FS038_dc5d4cb83c3888d70d}',''),
(40,40,'static','FORTIFY{FS039_0e250b5c2c8f8fda2d}',''),
(41,41,'static','FORTIFY{FS040_080c5a8ba6f3ff30ed}',''),
(42,42,'static','FORTIFY{FS041_432ca9de3d8fd8f61b}',''),
(43,43,'static','FORTIFY{FS042_dfb33cb0f6f3adff76}',''),
(44,44,'static','FORTIFY{FS043_28bb89dc407e6a65d0}',''),
(45,45,'static','FORTIFY{FS044_7abf1dac66495c8a04}',''),
(46,46,'static','FORTIFY{FS045_17e5a94343c9ea984a}',''),
(47,47,'static','FORTIFY{FS046_3f6897001c5672b5b4}',''),
(48,48,'static','FORTIFY{FS047_c386030486be11f63e}',''),
(49,49,'static','FORTIFY{FS048_e76b24cb7fb0ea443e}',''),
(50,50,'static','FORTIFY{FS049_7e825fe806e0d7907a}',''),
(51,51,'static','FORTIFY{FS050_ee0ba1f1e7ce9e5521}',''),
(52,52,'static','FORTIFY{FS051_9ab0c44f012c9d253b}',''),
(53,53,'static','FORTIFY{FS052_6f7c4843d2cbcce980}',''),
(54,54,'static','FORTIFY{FS053_ea8a9352138ca56581}',''),
(55,55,'static','FORTIFY{FS054_c5f3cb722f51f90aa4}',''),
(56,56,'static','FORTIFY{FS055_14e54437efe0c3fc10}',''),
(57,57,'static','FORTIFY{FS056_a26a744501ef20de8d}',''),
(58,58,'static','FORTIFY{FS057_b88320663475cd1bb8}',''),
(59,59,'static','FORTIFY{FS058_2d30293a643189df7f}',''),
(60,60,'static','FORTIFY{FS059_e9a8ad67ee58e5091c}',''),
(61,61,'static','FORTIFY{FS060_694437eb56677862d3}',''),
(62,62,'static','FORTIFY{FS061_3b4bb6dd66d5ff3967}',''),
(63,63,'static','FORTIFY{FS062_af21b6524703935218}',''),
(64,64,'static','FORTIFY{fs_063_230dcbe284f933fe226df2f1}',''),
(65,65,'static','FORTIFY{fs_064_e4acb13fc356ed2409783fb7}',''),
(66,66,'static','FORTIFY{fs_065_bf5b863d0b7c2968d4743004}',''),
(67,67,'static','FORTIFY{fs_066_f6205efb8ff1e684ce7cc500}',''),
(68,68,'static','FORTIFY{fs_067_cc644f13ea6da05d7ca8604c}',''),
(69,69,'static','FORTIFY{fs_068_ea5f19bc3bb7d9d74ad3b943}',''),
(70,70,'static','FORTIFY{fs_069_3d1b649900ed5abc2ccb3763}',''),
(71,71,'static','FORTIFY{fs_070_ddb8c76c4ebf6127807c7dbf}',''),
(72,72,'static','FORTIFY{fs_071_4458ce676bce899ef59d62a4}',''),
(73,73,'static','FORTIFY{fs_072_01fcafab005b7782899d9621}',''),
(74,74,'static','FORTIFY{fs_073_a743d7393ae7f0484484f317}',''),
(75,75,'static','FORTIFY{fs_074_da4255d7135546eccc2321de}',''),
(76,76,'static','FORTIFY{fs_075_7bfc92568de9ea85859fec5f}',''),
(77,77,'static','FORTIFY{fs_076_f1b285db7d15a7e67d47776e}',''),
(78,78,'static','FORTIFY{fs_077_14930756d39b831cccb259fb}',''),
(79,79,'static','FORTIFY{fs_078_3781d091ef3c423d8eefd0d9}',''),
(80,80,'static','FORTIFY{fs_079_bde3e2c59a531327030b79cb}',''),
(81,81,'static','FORTIFY{fs_080_f4683edfc75ed039f390a5b7}',''),
(82,82,'static','FORTIFY{fs_081_f576435ce9edb8b38407840c}',''),
(83,83,'static','FORTIFY{fs_082_bb4f83179b57e53fb9f908ed}',''),
(84,84,'static','FORTIFY{fs_083_205fb1d8c276f3197415bedd}',''),
(85,85,'static','FORTIFY{fs_084_cbde9fd44d9d9aae7e368ad3}',''),
(86,86,'static','FORTIFY{fs_085_638641a42e5ffce6f609b754}',''),
(87,87,'static','FORTIFY{fs_086_1abbfe4cea839d5da43a869e}',''),
(88,88,'static','FORTIFY{fs_087_fb918ad0f016becf11f87329}',''),
(89,89,'static','FORTIFY{fs_088_3b26aa1f6365a9ed7bc5ea1a}',''),
(90,90,'static','FORTIFY{fs_089_de288de77db4cf7bf4ba7d67}',''),
(91,91,'static','FORTIFY{fs_090_642f4545b4fe893201ce9d1c}',''),
(92,92,'static','FORTIFY{fs_091_7cee063b479f8fc23ea657ef}',''),
(93,93,'static','FORTIFY{fs_092_7fe838cc0ff0063b1e4bf456}',''),
(94,94,'static','FS{d4fe5086ac644f1ea5c8e71e}',NULL),
(95,95,'static','FS{619a4f086cc05b73db87b3ae}',NULL),
(96,96,'static','FS{b79d7e800f833945721bf1ef}',NULL),
(97,97,'static','FS{f58a4e50bcc47e18694c5be8}',NULL),
(98,98,'static','FS{38dd72f98eb66641ef7be17f}',NULL),
(99,99,'static','FS{d3efad02c9c6c941db7e26d2}',NULL),
(100,100,'static','FS{ac88d83cbee6cb7ac670f196}',NULL),
(101,101,'static','FS{651915d6af430044e4007180}',NULL),
(102,102,'static','FS{105534bd98af70e83caa0a60}',NULL),
(103,103,'static','FS{98dc2fd0a0536ff15843aa0a}',NULL),
(104,104,'static','FS{0b264583bfd6707fadde30b3}',NULL),
(105,105,'static','FS{1d055969b4dd81da1b6b3419}',NULL),
(106,106,'static','FS{f06ea40ea4cedcf6dce81634}',NULL),
(107,107,'static','FS{32eb63245f30da30bb52438d}',NULL),
(108,108,'static','FS{60ce864f5a82ae0f9cd6f3a6}',NULL),
(109,109,'static','FS{2367e7764637f36d72f45695}',NULL),
(110,110,'static','FS{fefc11bc443c30bc12d39e55}',NULL),
(111,111,'static','FS{16121774ba1b3616edf92647}',NULL),
(112,112,'static','FS{8efc8fb8de0f9df81db9a4d4}',NULL),
(113,113,'static','FS{dca6cbaf5639ebcadfd3c31e}',NULL),
(114,114,'static','FS{67a81f1f3474682441c7f325}',NULL),
(115,115,'static','FS{21d147c352c44087350ca529}',NULL),
(116,116,'static','FS{ff00a0979e34dde9f2473cee}',NULL),
(117,117,'static','FS{65ed0d0697923e5b152f130e}',NULL),
(118,118,'static','FS{96d9cdf971a828d04170b63e}',NULL),
(119,119,'static','FS{3219c802ce0be2aa78737fae}',NULL),
(120,120,'static','FS{ecddf1a3e36a30e5adae4d95}',NULL),
(121,121,'static','FS{f27d6034f17c9b860a7b2430}',NULL),
(122,122,'static','FS{026052fdb85f1beaeb4c9939}',NULL),
(123,123,'static','FS{ad0df7e9b7dfa811d10d1e20}',NULL),
(124,124,'static','FORTIFY{0bs1d14n_47_tru5t_4nch0r_r3v3rs3d_2026}',''),
(125,127,'static','FORTIFYSEC{timeline_rebuilt_9f2c7a41}',''),
(127,129,'static','FORTIFYSEC{5b7786554fbbd2c36c1484f76bf0d338b737d41d}',''),
(128,130,'static','FORTIFYSEC{CERBERUS_SUPPLY_CHAIN_TRUST_IS_EARNED_2026}','');
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hints`
--

DROP TABLE IF EXISTS `hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(80) DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`requirements`)),
  `title` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hints_ibfk_1` (`challenge_id`),
  CONSTRAINT `hints_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hints`
--

LOCK TABLES `hints` WRITE;
/*!40000 ALTER TABLE `hints` DISABLE KEYS */;
INSERT INTO `hints` VALUES
(1,'standard',124,'The validator works on 47 bytes and reorders them before comparing anything.',100,NULL,NULL),
(2,'standard',124,'Each round uses the previous *output* byte. Reverse the rounds in descending order.',200,NULL,NULL),
(3,'standard',124,'Undo modular addition, then rotate right, then XOR the key; finally invert the permutation.',300,NULL,NULL),
(4,'standard',127,'Find the session with a successful login, export and deletion in chronological order.',100,NULL,NULL),
(5,'standard',127,'Join gateway events and auth.sqlite3 by sid. The matching request_id appears in audit.jsonl.',200,NULL,NULL),
(6,'standard',127,'The seed is CASE-003|ORION|2026-10-29; derive SHA256 and XOR blob.bin with SHA256(key||nonce||counter_be32).',300,NULL,NULL),
(10,'standard',129,'Correlate auth and access by event_id AND trace; ordering matters.',200,NULL,NULL),
(11,'standard',129,'The five actions are session, pivot, ticket, archive, sealed.',350,NULL,NULL),
(12,'standard',129,'Search the bus for vault-seal and bridge-nonce channels.',500,NULL,NULL);
/*!40000 ALTER TABLE `hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(80) DEFAULT NULL,
  `route` varchar(128) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `auth_required` tinyint(1) DEFAULT NULL,
  `format` varchar(80) DEFAULT NULL,
  `link_target` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `route` (`route`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(2,'FortifySec CTF Arena 2027','arena','<div class=\"fs-home\">\r\n  <section class=\"fs-hero\">\r\n    <div class=\"fs-eyebrow\">◆ FORTIFYSEC / CTF ARENA 2027</div>\r\n    <h1>DOMINE A ARENA.<br><em>CAPTURE A FLAG.</em></h1>\r\n    <p>O campo de batalha é digital. Explore vulnerabilidades, decifre enigmas, investigue evidências e prove suas habilidades em uma competição de cibersegurança.</p>\r\n    <div class=\"fs-actions\">\r\n      <a class=\"fs-action\" href=\"/challenges\">Explorar desafios</a>\r\n      <a class=\"fs-action alt\" href=\"/scoreboard\">Ver ranking</a>\r\n      <a class=\"fs-action alt\" href=\"/register\">Entrar na competição</a>\r\n    </div>\r\n  </section>\r\n  <h2 class=\"fs-section-title\">R$ 5.000 em premiações</h2>\r\n  <div class=\"fs-grid\">\r\n    <article class=\"fs-tile\"><small>01 / Campeão</small><strong>R$ 3.000</strong><p>Primeiro lugar da competição.</p></article>\r\n    <article class=\"fs-tile\"><small>02 / Vice-campeão</small><strong>R$ 1.500</strong><p>Segundo lugar da competição.</p></article>\r\n    <article class=\"fs-tile\"><small>03 / Terceiro lugar</small><strong>R$ 500</strong><p>Terceiro lugar da competição.</p></article>\r\n  </div>\r\n  <h2 class=\"fs-section-title\">Escolha seu campo de batalha</h2>\r\n  <div class=\"fs-grid\">\r\n    <article class=\"fs-tile\"><small>01 / Exploração</small><strong>Web &amp; Pwn</strong><p>Falhas, exploração e raciocínio ofensivo.</p></article>\r\n    <article class=\"fs-tile\"><small>02 / Investigação</small><strong>OSINT &amp; Forense</strong><p>Pistas, rastros digitais e análise de evidências.</p></article>\r\n    <article class=\"fs-tile\"><small>03 / Lógica</small><strong>Criptografia</strong><p>Cifras, padrões e segredos para decifrar.</p></article>\r\n    <article class=\"fs-tile\"><small>04 / Engenharia</small><strong>Reversing</strong><p>Entenda programas e descubra seu funcionamento.</p></article>\r\n    <article class=\"fs-tile\"><small>05 / Infraestrutura</small><strong>Redes</strong><p>Protocolos, serviços e comunicação.</p></article>\r\n    <article class=\"fs-tile\"><small>06 / Competição</small><strong>Ranking</strong><p>Some pontos e avance na classificação.</p></article>\r\n  </div>\r\n  <p class=\"fs-footer\">FORTIFYSEC CTF ARENA 2027 · Conhecimento, técnica e competição.</p>\r\n</div>\r\n',0,1,0,'html',NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `review` varchar(2000) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`challenge_id`),
  KEY `challenge_id` (`challenge_id`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
INSERT INTO `ratings` VALUES
(1,1,94,1,NULL,'2026-11-03 21:12:35.782998'),
(2,1,96,1,NULL,'2026-11-03 21:19:00.748316'),
(3,1,1,1,NULL,'2026-11-05 12:21:19.076961');
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solutions`
--

DROP TABLE IF EXISTS `solutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `solutions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `state` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenge_id` (`challenge_id`),
  CONSTRAINT `solutions_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solutions`
--

LOCK TABLES `solutions` WRITE;
/*!40000 ALTER TABLE `solutions` DISABLE KEYS */;
/*!40000 ALTER TABLE `solutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solves`
--

DROP TABLE IF EXISTS `solves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `solves` (
  `id` int(11) NOT NULL,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenge_id` (`challenge_id`,`team_id`),
  UNIQUE KEY `challenge_id_2` (`challenge_id`,`user_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `solves_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_2` FOREIGN KEY (`id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solves_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solves`
--

LOCK TABLES `solves` WRITE;
/*!40000 ALTER TABLE `solves` DISABLE KEYS */;
INSERT INTO `solves` VALUES
(7,94,1,1),
(8,96,1,1),
(11,1,1,1);
/*!40000 ALTER TABLE `solves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `ip` varchar(46) DEFAULT NULL,
  `provided` text DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES
(1,1,1,1,'172.20.0.1','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-03 13:35:56.788751'),
(2,1,1,1,'172.20.0.1','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-03 13:36:00.307576'),
(3,1,1,1,'172.20.0.1','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-03 13:36:07.252245'),
(4,1,1,1,'172.20.0.1','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-03 13:36:10.324812'),
(5,1,1,1,'172.20.0.1','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-03 13:36:12.899566'),
(6,48,1,1,'172.20.0.1','','incorrect','2026-11-03 15:37:30.459586'),
(7,94,1,1,'201.71.136.106','FS{d4fe5086ac644f1ea5c8e71e}','correct','2026-11-03 21:12:29.839091'),
(8,96,1,1,'201.71.136.106','FS{b79d7e800f833945721bf1ef}','correct','2026-11-03 21:18:58.495417'),
(9,98,1,1,'201.71.136.106','','incorrect','2026-11-03 21:20:11.841533'),
(10,1,1,1,'201.71.136.106','FORTIFYS{CTF_INICIADO}','incorrect','2026-11-05 00:23:34.187085'),
(11,1,1,1,'201.71.136.106','FORTIFYS{CTF_INICIADO}','correct','2026-11-05 12:21:13.742372');
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge_id` int(11) DEFAULT NULL,
  `value` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_ibfk_1` (`challenge_id`),
  CONSTRAINT `tags_ibfk_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES
(1,124,'reverse'),
(2,124,'elf'),
(3,124,'x86-64'),
(4,124,'permutation'),
(5,124,'byte-transform'),
(6,124,'insane');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `website` varchar(128) DEFAULT NULL,
  `affiliation` varchar(128) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `captain_id` int(11) DEFAULT NULL,
  `bracket_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id` (`id`,`oauth_id`),
  UNIQUE KEY `oauth_id` (`oauth_id`),
  KEY `team_captain_id` (`captain_id`),
  KEY `bracket_id` (`bracket_id`),
  CONSTRAINT `team_captain_id` FOREIGN KEY (`captain_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`bracket_id`) REFERENCES `brackets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES
(1,NULL,'luanpatrickbo',NULL,'$bcrypt-sha256$v=2,t=2b,r=12$/0VnmT8aq1mrCkc73xOP5u$fvt8nvSFZ.62f3v8s6x3xldhUaTQJaC',NULL,NULL,NULL,NULL,1,0,'2026-11-03 12:41:14.189262',1,NULL);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `expiration` datetime(6) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES
(1,'user',1,'2026-11-03 15:14:05.157085','2027-03-11 00:00:00.000000','ctfd_1ae651c6a1ccd54aac06f9e77ec7af9c8f15f0501fa3ac3432752ac3b4f8726e',''),
(2,'user',1,'2026-11-03 15:25:20.601611','2027-11-03 00:00:00.000000','ctfd_80afce7e9eccb887129d07c64995291a88f620c61c2e23873b697d992322ab0d',''),
(3,'user',1,'2026-11-03 17:57:59.859271','2026-04-11 00:00:00.000000','ctfd_cfdb509b789dc2524161092e68ea91ca874eeba803ebc79ceffbbe41907e6d5f',''),
(4,'user',1,'2026-11-03 17:58:23.164330','2027-04-11 00:00:00.000000','ctfd_e74a282e436b19d4bac6b98deac97db11b433ced59a9dd6fb7081194664d7651',''),
(5,'user',1,'2026-11-03 18:09:08.246754','2027-12-31 00:00:00.000000','ctfd_1d322deec14c5edc5b1dc835a4b32c7eec8beecd1d7c6e05631995b8b836a792','');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracking`
--

DROP TABLE IF EXISTS `tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) DEFAULT NULL,
  `ip` varchar(46) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `target` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tracking_ibfk_1` (`user_id`),
  CONSTRAINT `tracking_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracking`
--

LOCK TABLES `tracking` WRITE;
/*!40000 ALTER TABLE `tracking` DISABLE KEYS */;
INSERT INTO `tracking` VALUES
(1,NULL,'172.20.0.1',1,'2026-11-03 15:45:47.398264',NULL),
(2,NULL,'172.20.0.1',2,'2026-11-03 14:48:21.936289',NULL),
(3,NULL,'168.205.50.147',1,'2026-11-04 18:52:14.655948',NULL),
(4,NULL,'201.71.136.106',2,'2026-11-03 17:50:59.298227',NULL),
(5,NULL,'201.71.136.106',1,'2026-11-05 12:21:19.067613',NULL),
(6,NULL,'2804:7850:100:9e00:bfa3:95a7:4052:3f91',1,'2026-11-04 06:13:41.092688',NULL);
/*!40000 ALTER TABLE `tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unlocks`
--

DROP TABLE IF EXISTS `unlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `target` int(11) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unlocks_ibfk_1` (`team_id`),
  KEY `unlocks_ibfk_2` (`user_id`),
  CONSTRAINT `unlocks_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `unlocks_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unlocks`
--

LOCK TABLES `unlocks` WRITE;
/*!40000 ALTER TABLE `unlocks` DISABLE KEYS */;
INSERT INTO `unlocks` VALUES
(1,1,1,10,'2026-11-04 18:26:31.787676','hints'),
(2,1,1,11,'2026-11-04 18:26:39.379764','hints');
/*!40000 ALTER TABLE `unlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `type` varchar(80) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `website` varchar(128) DEFAULT NULL,
  `affiliation` varchar(128) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `bracket_id` int(11) DEFAULT NULL,
  `change_password` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `id` (`id`,`oauth_id`),
  UNIQUE KEY `oauth_id` (`oauth_id`),
  KEY `team_id` (`team_id`),
  KEY `bracket_id` (`bracket_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`bracket_id`) REFERENCES `brackets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'luanpatrickbo','$bcrypt-sha256$v=2,t=2b,r=12$/dt5/NGWHQe/.00mes5rwu$fzid40Ka/f4rfdkb8y/BpfWQTMFNdQi','luanpatrickbo4@gmail.com','admin',NULL,NULL,NULL,NULL,1,0,0,1,'2026-11-03 12:20:28.899915','pt_BR',NULL,0),
(2,NULL,'bitmaverick','$bcrypt-sha256$v=2,t=2b,r=12$zwsZZ/e2bMiAXkq.anfXQe$dhR.nsuu1iNsg3kB38fw5Yv5bRGkuAy','contato@luanpatrick.com.br','user',NULL,'https://www.luanpatrick.com.br','SENAI','BR',0,0,0,NULL,'2026-11-03 14:26:47.074885','pt_BR',NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ctfd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-05 13:00:10
