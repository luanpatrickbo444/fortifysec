FORTIFYSEC ELITE LABS — LOTE DE HOMOLOGACAO 01

6 laboratorios funcionais (nao 50).
Arquivos em PARTICIPANTES sao para distribuicao. ADMIN_PRIVADO contem flags e solucoes: NAO publicar.
Os binarios sao vulneraveis intencionalmente; use VM/container isolado. Web vincula 127.0.0.1.
Validacao automatizada executada; falta revisao humana independente.
