# FS-083 — Custom Executable Format

Categoria: Reverse. Pontos: 1300.

Missão: reconstituir a evidência fragmentada, identificar os eventos autênticos, aplicar a cadeia de transformações na ordem inversa, descomprimir o registro e validar o SHA-256 do token recuperado.

Artefatos: `casefile.json`, `pipeline.json`, `telemetry.jsonl`.

Todos os dados são sintéticos; não há serviços externos.
