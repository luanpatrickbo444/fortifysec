# ELF Checkpoint

Analise um binario ELF Linux x86-64 e recupere o token de validacao. Ferramentas sugeridas: file, strings, objdump, Ghidra e GDB.

Ambiente: execute apenas localmente ou em VM isolada.
