# DNS Exfil Fragments

Examine o PCAP no Wireshark ou tshark. Um agente fragmentou um segredo em consultas DNS. Reconstrua os fragmentos pela ordem indicada.

Ambiente: execute apenas localmente ou em VM isolada.
