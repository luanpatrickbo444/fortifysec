# Operacao Aurora

Investigue um conjunto de documentos ficticios offline. Correlacione identificadores, ordem de montagem e fragmentos para reconstruir a flag.

Ambiente: execute apenas localmente ou em VM isolada.
