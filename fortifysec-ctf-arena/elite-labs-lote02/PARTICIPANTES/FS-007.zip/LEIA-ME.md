# Tenant Boundary II

Execute `python3 server.py` e investigue o controle de acesso da API local. Seu objetivo e recuperar a informacao pertencente a outro tenant.

Ambiente: execute apenas localmente ou em VM isolada.
