from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse,parse_qs
import json
DATA={"101":{"owner":"alpha","note":"Pedido de rotina"},"102":{"owner":"beta","note":'FSCTF{TENANT_BOUNDARY_14C8FE49DF}'}}
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  p=urlparse(self.path)
  if p.path!='/api/invoices':self.send_error(404);return
  q=parse_qs(p.query);user=q.get('tenant',['alpha'])[0];invoice=q.get('id',['101'])[0]
  if invoice not in DATA:self.send_error(404);return
  # LAB: o servidor nao verifica se o registro pertence ao tenant autenticado.
  body=json.dumps(DATA[invoice]).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
HTTPServer(('127.0.0.1',8765),H).serve_forever()
