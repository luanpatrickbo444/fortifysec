# Keystream Collision

Dois fluxos foram cifrados com a mesma chave XOR. Voce conhece o texto claro do primeiro. Recupere a mensagem confidencial do segundo.

Ambiente: execute apenas localmente ou em VM isolada.
