# Use bytes.fromhex e XOR para recuperar o fluxo de chave.
