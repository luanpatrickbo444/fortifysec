# Audit Trail Recovery

Analise o banco SQLite de um sistema de auditoria. Identifique a evidencia de recuperacao registrada logo apos uma exclusao suspeita.

Ambiente: execute apenas localmente ou em VM isolada.
